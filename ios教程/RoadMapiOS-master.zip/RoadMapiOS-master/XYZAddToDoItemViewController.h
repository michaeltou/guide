//
//  XYZAddToDoItemViewController.h
//  ToDoList
//
//  Created by Mrshyi on 14-5-28.
//  Copyright (c) 2014年 Maclove. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XYZToDoItem.h"
@interface XYZAddToDoItemViewController : UIViewController
@property XYZToDoItem *toDoItem;
@end
