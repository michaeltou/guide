//
//  XYZToDoListTableViewController.h
//  ToDoList
//
//  Created by Mrshyi on 14-5-28.
//  Copyright (c) 2014年 Maclove. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XYZToDoListTableViewController : UITableViewController

-(IBAction)unwindToList:(UIStoryboardSegue *)segue;
@end
