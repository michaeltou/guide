//
//  XYZAppDelegate.h
//  ToDoList
//
//  Created by Mrshyi on 14-5-27.
//  Copyright (c) 2014年 Maclove. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XYZAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
