//
//  main.m
//  ToDoList
//
//  Created by Mrshyi on 14-5-27.
//  Copyright (c) 2014年 Maclove. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "XYZAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([XYZAppDelegate class]));
    }
}
